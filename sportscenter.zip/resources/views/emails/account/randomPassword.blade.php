<div>
    Hello, You are log in using google
    Here is your password:
    {{$password}}
</div>