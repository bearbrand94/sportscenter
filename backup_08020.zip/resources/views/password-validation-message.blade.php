<div class="alert alert-primary mb-0">
  <strong>Password minimal 6 karakter berupa kombinasi angka dan huruf kecil</strong>
</div>