<button class="btn shadow" style="background-color: white; border-radius: 1rem; padding: 3px 10px; padding-right:15px; font-size: 0.85rem; font-weight: 600;" data-toggle="modal" data-target="#filter-modal">
	<img src="{{asset('images/filter.svg')}}" class="pt-1"></img>Urutkan & Filter
</button>